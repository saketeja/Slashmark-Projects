export const COPY_SUCCESS = "Password successfully copied to clipboard"
export const COPY_Fail = "Password successfully copied to clipboard"